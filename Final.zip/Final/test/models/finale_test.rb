require 'test_helper'

class FinaleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
