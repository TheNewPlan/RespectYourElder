class Finale < ApplicationRecord
end
