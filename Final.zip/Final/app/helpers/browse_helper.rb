module BrowseHelper
end
