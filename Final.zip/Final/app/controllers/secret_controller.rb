class SecretController < ApplicationController
end
